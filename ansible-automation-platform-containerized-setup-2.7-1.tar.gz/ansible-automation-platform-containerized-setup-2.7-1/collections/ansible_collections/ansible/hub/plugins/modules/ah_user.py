#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2021, Herve Quatremain <hquatrem@redhat.com>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

# You can consult the UI API documentation directly on a running private
# automation hub at https://hub.example.com/pulp/api/v3/docs/


from __future__ import absolute_import, division, print_function

__metaclass__ = type


DOCUMENTATION = r"""
---
module: ah_user
short_description: Manage private automation hub users
description:
  - Create, delete, and update user accounts in private automation hub.
  - B(Deprecated) when used with AAP 2.5 or 2.6. This module will be removed in AAP 2.7.
    In AAP 2.7, user management is handled through the AAP Gateway.
author:
  - Herve Quatremain (@herve4m)
options:
  username:
    description:
      - Name of the user to create, remove, or modify.
    required: true
    type: str
  groups:
    description:
      - List of the groups the user is added to. When not set or set to an
        empty list (V([])), the module removes the user from all groups.
    type: list
    elements: str
  append:
    description:
      - If V(yes), then add the user to the groups specified in O(groups).
      - If V(no), then the module only adds the user to the groups specified in
        O(groups), removing them from all other groups.
    type: bool
    default: yes
  first_name:
    description:
      - User's first name.
    type: str
  last_name:
    description:
      - User's last name.
    type: str
  email:
    description:
      - User's email address. That address must be correctly formed.
    type: str
  is_superuser:
    description:
      - Gives the super user permissions to the user.
    type: bool
    default: False
    aliases: ['superuser']
  password:
    description:
      - User's password as a clear string. The password must contain at least 9 characters with numbers or special characters.
    type: str
  state:
    description:
      - If V(absent), then the module deletes the user.
      - The module does not fail if the user does not exist because the state is already as expected.
      - If V(present), then the module creates the user if it does not already exist.
        If the user account already exists, then the module updates its state.
    type: str
    default: present
    choices: [absent, present]
notes:
  - Supports C(check_mode).
extends_documentation_fragment: ansible.hub.auth_ui
"""

EXAMPLES = r"""
- name: Ensure the user exists
  ansible.hub.ah_user:
    username: lvasquez
    first_name: Lena
    last_name: Vasquez
    email: lvasquez@example.com
    password: vs9mrD55NP
    groups:
      - operators
    state: present
    ah_host: hub.example.com
    ah_username: admin
    ah_password: Sup3r53cr3t
  no_log: true

- name: Ensure the user is removed
  ansible.hub.ah_user:
    username: dwilde
    state: absent
    ah_host: hub.example.com
    ah_username: admin
    ah_password: Sup3r53cr3t
  no_log: true

- name: Ensure the user only belongs to the operators and developers groups
  ansible.hub.ah_user:
    username: qhazelrigg
    state: present
    groups:
      - operators
      - developers
    append: false
    ah_host: hub.example.com
    ah_username: admin
    ah_password: Sup3r53cr3t
  no_log: true

- name: Ensure the user is added to the managers group
  ansible.hub.ah_user:
    username: chorwitz
    state: present
    groups:
      - managers
    append: true
    ah_host: hub.example.com
    ah_username: admin
    ah_password: Sup3r53cr3t
  no_log: true

- name: Ensure the password is changed
  ansible.hub.ah_user:
    username: jziglar
    state: present
    password: bQtVeBUK2F
    ah_host: hub.example.com
    ah_username: admin
    ah_password: Sup3r53cr3t
  no_log: true

- name: Ensure the user is a super user
  ansible.hub.ah_user:
    username: ekrob
    state: present
    is_superuser: true
    ah_host: hub.example.com
    ah_username: admin
    ah_password: Sup3r53cr3t
  no_log: true
"""

RETURN = r""" # """

from ..module_utils.ah_api_module import AHAPIModule
from ..module_utils.ah_ui_object import AHUIUser, AHUIGroup


def main():
    argument_spec = dict(
        username=dict(required=True),
        first_name=dict(),
        last_name=dict(),
        email=dict(),
        is_superuser=dict(type="bool", default=False, aliases=["superuser"]),
        password=dict(no_log=True),
        groups=dict(type="list", elements="str"),
        append=dict(type="bool", default=True),
        state=dict(choices=["present", "absent"], default="present"),
    )

    # Create a module for ourselves
    module = AHAPIModule(argument_spec=argument_spec, supports_check_mode=True)

    # Extract our parameters
    username = module.params.get("username")
    first_name = module.params.get("first_name")
    last_name = module.params.get("last_name")
    email = module.params.get("email")
    is_superuser = module.params.get("is_superuser")
    password = module.params.get("password")
    groups = module.params.get("groups")
    append = module.params.get("append")
    state = module.params.get("state")

    # Authenticate
    module.authenticate()
    vers = module.get_server_version()
    user = AHUIUser(module)

    # AHAPIModule.get_server_version() returns a LooseVersion object, so
    # string comparisons like vers >= "4.12" work via LooseVersion.__ge__.
    # This differs from ah_token.py which uses AHModule (no built-in version
    # detection) and constructs LooseVersion explicitly.
    if module.behind_resource_server:
        if vers >= "4.12":
            module.fail_json(
                msg=(
                    "The ah_user module is not supported in AAP 2.7+ (Hub {vers}). "
                    "User management is handled through the AAP Gateway. "
                    "Use the ansible.platform collection or AAP Gateway UI to manage users instead."
                ).format(vers=vers)
            )
        elif vers >= "4.10":
            module.warn(
                "The ah_user module is deprecated when used with AAP 2.5+ (Hub {vers}) "
                "and will be removed in AAP 2.7. User management should be done through "
                "the AAP Gateway. Use the ansible.platform collection or AAP Gateway UI "
                "to manage users instead.".format(vers=vers)
            )

    # Get the user details from its name.
    # API (GET): /api/galaxy/_ui/v1/users/?username=<user_name>
    user.get_object(username, vers)

    # Removing the user
    if state == "absent":
        # Cannot delete an account that has the super user flag.
        # First, remove that super user status from the account.
        if user.superuser:
            new_fields = {"username": username, "is_superuser": False}
            user.update(new_fields, auto_exit=False)
        user.delete()

    # Confirm that all the given groups exist and retrieve their details
    group = AHUIGroup(module)
    group_ids = []
    if groups is not None:
        error_groups = []
        for group_name in groups:
            group.get_object(group_name, vers)
            if group.exists:
                group_ids.append(group.data)
            else:
                error_groups.append(group_name)
        if error_groups:
            module.fail_json(msg="unknown groups: %s" % ", ".join(error_groups))

    # Create the data that gets sent for create and update
    new_fields = {}
    if username is not None:
        new_fields["username"] = username
    if first_name is not None:
        new_fields["first_name"] = first_name
    if last_name is not None:
        new_fields["last_name"] = last_name
    if email is not None:
        new_fields["email"] = email
    if is_superuser is not None:
        new_fields["is_superuser"] = is_superuser
    if password is not None:
        new_fields["password"] = password

    if append and user.exists:
        ids = [v["id"] for v in group_ids]
        for g in user.groups:
            if "id" in g and g["id"] not in ids:
                group_ids.append(g)
    new_fields["groups"] = group_ids

    # API (POST): /api/galaxy/_ui/v1/users/
    # API (PUT): /api/galaxy/_ui/v1/users/<USER_ID#>/
    user.create_or_update(new_fields)


if __name__ == "__main__":
    main()
